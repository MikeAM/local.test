<?php



for ( $x = 70; $x > 0; $x-- ) {
	$y = (1000 - (12 * $x)) / 11;
	if ( is_int($y) ) {
		echo '<p>Columns: '.$x.'px</p>';
		echo '<p>Gutters: '.$y.'px</p>';
		echo '<p>Ratio: '.($x / $y).':1</p>';
		echo '<hr>';
	}
}

?>
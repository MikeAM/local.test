//$(function() {
//	$('#menu-items').sortable();
//	$('#menu-items').disableSelection();
//});